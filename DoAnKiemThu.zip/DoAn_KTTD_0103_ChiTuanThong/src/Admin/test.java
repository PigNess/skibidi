package Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class test {

    WebDriver driver;
    String baseUrl = "https://elearning.plt.pro.vn/dang-nhap?redirect=%2Ftrang-chu";
    String driverPath = "C:\\chromedriver.exe";

    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get(baseUrl);
        Thread.sleep(3000);

        // ⚠️ Nếu hệ thống yêu cầu đăng nhập
        driver.findElement(By.id("input-10")).sendKeys("test.pltsolutions@gmail.com"); // TODO
        driver.findElement(By.id("input-13")).sendKeys("plt@intern_051224"); // TODO
        driver.findElement(By.xpath("//*[@id=\"app\"]/div/main/div/div[1]/div/div[3]/form/div[2]/button/span")).click(); // TODO

        Thread.sleep(3000);
    }
    
    @Test
    public void Them_Tim_SoSanh_HocVien() throws InterruptedException {

        // ===== DỮ LIỆU MONG ĐỢI =====
        String tenMongDoi = "Nguyen Van Chi";
        String emailMongDoi = "nguyenvanchi@gmail.com";
        String ngaySinhMongDoi = "01/01/2000";
        String diaChiMongDoi = "TP Ho Chi Minh";

     // ===== BƯỚC MỚI: CHỌN QUẢN LÝ HỌC VIÊN =====
        driver.findElement(By.xpath("//*[@id=\"app\"]/div/nav/div[1]/div[2]/a[2]/div[2]"))
                .click(); // 
        Thread.sleep(3000);
        // ===== b1: THÊM HỌC VIÊN =====
        driver.findElement(By.xpath("//*[@id=\"v-main-app\"]/div/div/div/div[1]/header/div/button[1]")).click(); // TODO
        Thread.sleep(2000);

        driver.findElement(By.id("INPUT_FULLNAME")).sendKeys(tenMongDoi); // TODO
        driver.findElement(By.id("INPUT_EMAIL")).sendKeys(emailMongDoi); // TODO
        driver.findElement(By.id("INPUT_BIRTHDAY")).sendKeys(ngaySinhMongDoi); // TODO
        driver.findElement(By.id("INPUT_ADDRESS")).sendKeys(diaChiMongDoi); // TODO

        driver.findElement(By.id("BTN_SAVE")).click(); // TODO
        Thread.sleep(3000);

        // ===== b2: TÌM KIẾM HỌC VIÊN =====
        driver.findElement(By.id("INPUT_SEARCH")).clear(); // TODO
        driver.findElement(By.id("INPUT_SEARCH")).sendKeys(tenMongDoi);
        Thread.sleep(3000);

        // ===== b3: LẤY GIÁ TRỊ THỰC TẾ =====
        String tenThucTe = driver.findElement(
                By.xpath("//table/tbody/tr[1]/td[NAME_COL]") // TODO
        ).getText();

        String emailThucTe = driver.findElement(
                By.xpath("//table/tbody/tr[1]/td[EMAIL_COL]") // TODO
        ).getText();

        String ngaySinhThucTe = driver.findElement(
                By.xpath("//table/tbody/tr[1]/td[BIRTH_COL]") // TODO
        ).getText();

        String diaChiThucTe = driver.findElement(
                By.xpath("//table/tbody/tr[1]/td[ADDRESS_COL]") // TODO
        ).getText();

        // ===== SO SÁNH (GIỐNG BÀI BẠN GỬI) =====
        System.out.println("===== KẾT QUẢ SO SÁNH HỌC VIÊN =====");

        if (tenThucTe.equalsIgnoreCase(tenMongDoi)) {
            System.out.println("TÊN PASS: " + tenThucTe);
        } else {
            System.out.println("TÊN FAIL: " + tenThucTe);
        }

        if (emailThucTe.equalsIgnoreCase(emailMongDoi)) {
            System.out.println("EMAIL PASS: " + emailThucTe);
        } else {
            System.out.println("EMAIL FAIL: " + emailThucTe);
        }

        if (ngaySinhThucTe.equalsIgnoreCase(ngaySinhMongDoi)) {
            System.out.println("NGÀY SINH PASS: " + ngaySinhThucTe);
        } else {
            System.out.println("NGÀY SINH FAIL: " + ngaySinhThucTe);
        }

        if (diaChiThucTe.equalsIgnoreCase(diaChiMongDoi)) {
            System.out.println("ĐỊA CHỈ PASS: " + diaChiThucTe);
        } else {
            System.out.println("ĐỊA CHỈ FAIL: " + diaChiThucTe);
        }

        System.out.println("===== HOÀN TẤT KIỂM THỬ =====");
    }

    @AfterTest
    public void tearDown() {
        driver.close();
    }
}

