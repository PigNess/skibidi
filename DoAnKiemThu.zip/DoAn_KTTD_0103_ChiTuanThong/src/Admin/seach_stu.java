package Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class seach_stu {

    WebDriver driver;
    WebDriverWait wait;

    String baseUrl = "https://elearning.plt.pro.vn/dang-nhap?redirect=%2Ftrang-chu";
    String driverPath = "C:\\chromedriver.exe";

    // ===== DỮ LIỆU SEARCH =====
    String keywordSearch = "SV27364";

    // ===== DỮ LIỆU MONG ĐỢI (SO SÁNH) =====
    String tenMongDoi = "Nguyen Van";
    String emailMongDoi = "nguyenvanchi@gmail.com";
    String ngaySinhMongDoi = "01-02-2000";
    String diaChiMongDoi = "64/12 An Phu, Thu Duc, TP HCM";

    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, 10);

        driver.manage().window().maximize();

        // ===== LOGIN =====
        driver.get(baseUrl);
        Thread.sleep(3000);

        driver.findElement(By.id("input-10"))
                .sendKeys("test.pltsolutions@gmail.com");

        driver.findElement(By.id("input-13"))
                .sendKeys("plt@intern_051224");

        driver.findElement(By.xpath(
                "//*[@id='app']/div/main/div/div[1]/div/div[3]/form/div[2]/button/span"
        )).click();

        Thread.sleep(4000);

        // ===== VÀO QUẢN LÝ HỌC VIÊN =====
        driver.findElement(By.xpath(
                "//*[@id=\"app\"]/div[1]/nav/div[1]/div[2]/a[2]/div[2]"
        )).click();

        Thread.sleep(3000);
    }

    @Test
    public void TimKiemHocVien_TheoTen() throws InterruptedException {

        // ===== NHẬP SEARCH =====
        WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//*[@id=\"input-41\"]")
                // TODO: nếu trang có nhiều input → chỉnh xpath cho đúng ô Search
        ));

        searchBox.clear();
        searchBox.sendKeys(keywordSearch);

        Thread.sleep(2000);

        // ===== DÒNG KẾT QUẢ ĐẦU TIÊN =====
        WebElement dongDauTien = wait.until(
        	    ExpectedConditions.visibilityOfElementLocated(
        	        By.xpath("//*[@id=\"v-main-app\"]/div/div/div/div[1]/div[1]/table/tbody/tr[1]")
        	    )
        	);

        	System.out.println("✅ Tìm thấy dòng kết quả");

        	// GỌI SO SÁNH + IN KẾT QUẢ
        	soSanhThongTinHocVien(dongDauTien);
    }
    // ================== SO SÁNH ==================

    void soSanhThongTinHocVien(WebElement dongDauTien) {

        // LẤY GIÁ TRỊ THỰC TẾ TỪ BẢNG
        String tenThucTe = dongDauTien.findElement(By.xpath("//*[@id=\"v-main-app\"]/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[2]")).getText()
                            + " " +
                            dongDauTien.findElement(By.xpath("//*[@id=\"v-main-app\"]/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[3]")).getText();

        String emailThucTe = dongDauTien.findElement(By.xpath("//*[@id=\"v-main-app\"]/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[5]")).getText();
        String ngaySinhThucTe = dongDauTien.findElement(By.xpath("//*[@id=\"v-main-app\"]/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[6]")).getText();
        String diaChiThucTe = dongDauTien.findElement(By.xpath("//*[@id=\"v-main-app\"]/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[8]")).getText();

        System.out.println("===== KẾT QUẢ SO SÁNH HỌC VIÊN =====");

        soSanhVaInKetQua("Tên", tenThucTe, tenMongDoi);
        soSanhVaInKetQua("Email", emailThucTe, emailMongDoi);
        soSanhVaInKetQua("Ngày sinh", ngaySinhThucTe, ngaySinhMongDoi);
        soSanhVaInKetQua("Địa chỉ", diaChiThucTe, diaChiMongDoi);

        System.out.println("===================================");
    }



    void soSanhVaInKetQua(String field, String actual, String expected) {

        actual = actual.trim();
        expected = expected.trim();

        if (actual.equalsIgnoreCase(expected)) {
            System.out.println(
                field + " : PASS | Actual = " + actual + " | Expected = " + expected
            );
        } else {
            System.out.println(
                field + " : FAIL | Actual = " + actual + " | Expected = " + expected
            );
        }
    }


    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
