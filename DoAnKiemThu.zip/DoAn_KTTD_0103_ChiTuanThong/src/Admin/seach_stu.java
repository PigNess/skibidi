package Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class seach_stu {

    WebDriver driver;
    WebDriverWait wait;

    String baseUrl = "https://elearning.plt.pro.vn/dang-nhap?redirect=%2Ftrang-chu";
    String driverPath = "C:\\chromedriver.exe";

    // ===== DỮ LIỆU TEST =====
    String tenHocVienCanTim = "SV27364";

    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, 10);

        driver.manage().window().maximize();

        // ===== LOGIN =====
        driver.get(baseUrl);
        Thread.sleep(3000);

        driver.findElement(By.id("input-10"))
                .sendKeys("test.pltsolutions@gmail.com");

        driver.findElement(By.id("input-13"))
                .sendKeys("plt@intern_051224");

        driver.findElement(By.xpath(
                "//*[@id='app']/div/main/div/div[1]/div/div[3]/form/div[2]/button/span"
        )).click();

        Thread.sleep(4000);

        // ===== VÀO QUẢN LÝ HỌC VIÊN =====
        driver.findElement(By.xpath(
                "//*[@id='app']/div/nav/div[1]/div[2]/a[2]/div[2]"
        )).click();

        Thread.sleep(3000);
    }

    @Test
    public void TimKiemHocVien_TheoTen() throws InterruptedException {

        // ===== NHẬP TÊN CẦN TÌM =====
        WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(
        		By.xpath("//label[normalize-space(text())='Search']/following::input[1]")
 // 🔴 lấy từ ảnh bạn gửi
        ));

        searchBox.clear();
        searchBox.sendKeys(tenHocVienCanTim);

        Thread.sleep(2000);

        // ===== KIỂM TRA CÓ KẾT QUẢ =====
        WebElement dongDauTien = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//table/tbody/tr[1]")
        ));

        String ketQua = dongDauTien.getText();

        if (ketQua.contains(tenHocVienCanTim)) {
            System.out.println("✅ SEARCH PASS – Tìm thấy học viên: " + tenHocVienCanTim);
        } else {
            System.out.println("❌ SEARCH FAIL – Không đúng học viên");
        }
    }

    @AfterTest
    public void tearDown() {
        driver.close();
    }
}
