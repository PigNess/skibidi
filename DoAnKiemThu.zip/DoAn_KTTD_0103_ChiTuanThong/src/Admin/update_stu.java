package Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.*;
import org.openqa.selenium.Keys;


public class update_stu {

    WebDriver driver;
    WebDriverWait wait;

    String baseUrl = "https://elearning.plt.pro.vn/dang-nhap?redirect=%2Ftrang-chu";
    String driverPath = "C:\\chromedriver.exe";

    String tenHocVien = "Nguyen Van";
    String diaChiMoi = "Ha Huy Tap, Quan 10, TP HCM";

    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, 10);

        driver.manage().window().maximize();
        driver.get(baseUrl);
        Thread.sleep(3000);

        // LOGIN
        driver.findElement(By.id("input-10")).sendKeys("test.pltsolutions@gmail.com");
        driver.findElement(By.id("input-13")).sendKeys("plt@intern_051224");
        driver.findElement(By.xpath(
            "//*[@id='app']/div/main/div/div[1]/div/div[3]/form/div[2]/button/span"
        )).click();

        Thread.sleep(4000);

        // VÀO QUẢN LÝ HỌC VIÊN
        driver.findElement(By.xpath(
            "//*[@id='app']/div/nav/div[1]/div[2]/a[2]/div[2]"
        )).click();

        Thread.sleep(3000);
    }

    @Test
    public void SuaThongTinHocVien() throws InterruptedException {

        // ===== SEARCH =====
        WebElement searchBox = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//label[normalize-space(text())='Search']/following::input[1]")
            )
        );
        searchBox.clear();
        searchBox.sendKeys(tenHocVien);
        Thread.sleep(2000);

        // ===== CLICK ICON SỬA (✏️) =====
     // ===== CLICK ICON SỬA =====
        driver.findElement(By.xpath(
            "//table/tbody/tr[1]//i[contains(@class,'mdi-pencil')]"
        )).click();

        Thread.sleep(2000);

        // ===== SỬA ĐỊA CHỈ =====
        WebElement diaChiInput = wait.until(
        	    ExpectedConditions.visibilityOfElementLocated(
        	        By.xpath("//label[normalize-space(text())='Địa chỉ']/following::input[1]")
        	    )
        	);

        	diaChiInput.click();
        	diaChiInput.sendKeys(Keys.CONTROL + "a");
        	diaChiInput.sendKeys(Keys.DELETE);
        	diaChiInput.sendKeys(diaChiMoi);

        // ===== LƯU =====
        driver.findElement(By.xpath(
            "//form//button[@type='submit']"
        )).click();

        // ===== OK POPUP =====
        wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//button[contains(@class,'swal2-confirm')]")
        )).click();

        System.out.println("✅ SỬA HỌC VIÊN THÀNH CÔNG");
    }

    @AfterTest
    public void tearDown() {
        driver.close();
    }
}
