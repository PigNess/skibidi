package Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

public class update_stu {

    WebDriver driver;
    WebDriverWait wait;

    String baseUrl = "https://elearning.plt.pro.vn/dang-nhap?redirect=%2Ftrang-chu";
    String driverPath = "C:\\chromedriver.exe";

    // ===== DỮ LIỆU TEST =====
    String keywordSearch = "sv12005";

    // ===== DỮ LIỆU MONG ĐỢI SAU KHI UPDATE =====
    String tenMongDoi = "Nguyen Van Chi";
    String emailMongDoi = "nguyenvanchi@gmail.com";
    String ngaySinhMongDoi = "01-01-2000";
    String diaChiMoi = "Ha Huy Giáp, Quan 10, TP HCM";

    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, 10);

        driver.manage().window().maximize();
        driver.get(baseUrl);
        Thread.sleep(3000);

        // ===== LOGIN =====
        driver.findElement(By.id("input-10"))
              .sendKeys("test.pltsolutions@gmail.com");
        driver.findElement(By.id("input-13"))
              .sendKeys("plt@intern_051224");

        driver.findElement(By.xpath(
            "//*[@id='app']/div/main/div/div[1]/div/div[3]/form/div[2]/button/span"
        )).click();

        Thread.sleep(4000);

        // ===== VÀO QUẢN LÝ HỌC VIÊN =====
        driver.findElement(By.xpath(
        		"//*[@id=\"app\"]/div[1]/nav/div[1]/div[2]/a[2]/div[2]"
        )).click();

        Thread.sleep(3000);
    }

    @Test
    public void UpdateHocVien_Va_SoSanhThongTin() throws InterruptedException {

        // ===== SEARCH HỌC VIÊN =====
        WebElement searchBox = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//*[@id=\"v-main-app\"]/div/div/div/div[1]/header/div/div[3]")
            )
        );
        searchBox.clear();
        searchBox.sendKeys(keywordSearch);
        Thread.sleep(2000);

        // ===== CLICK ICON SỬA =====
        driver.findElement(By.xpath(
            "//*[@id=\"v-main-app\"]/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[10]/button[1]/span"
        )).click();

        Thread.sleep(2000);

        // ===== SỬA ĐỊA CHỈ =====
        WebElement diaChiInput = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.id("")
            )
        );

        diaChiInput.click();
        diaChiInput.sendKeys(Keys.CONTROL + "a");
        diaChiInput.sendKeys(Keys.DELETE);
        diaChiInput.sendKeys(diaChiMoi);

        // ===== LƯU =====
        driver.findElement(By.xpath("//form//button[@type='submit']")).click();

        // ===== OK POPUP =====
        wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//button[contains(@class,'swal2-confirm')]")
        )).click();

        System.out.println("✅ UPDATE THÀNH CÔNG");

        Thread.sleep(3000);

        // ===== SEARCH LẠI SAU UPDATE =====
        searchBox.clear();
        searchBox.sendKeys(keywordSearch);
        Thread.sleep(2000);

        WebElement dongDauTien = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[@id='v-main-app']//table/tbody/tr[1]")
            )
        );

        System.out.println("✅ Tìm thấy dòng kết quả sau UPDATE");

        // ===== SO SÁNH =====
        soSanhThongTinHocVien(dongDauTien);
    }

    // ================== SO SÁNH ==================

    void soSanhThongTinHocVien(WebElement dongDauTien) {

        String tenThucTe =
            dongDauTien.findElement(By.xpath("./td[2]")).getText() + " " +
            dongDauTien.findElement(By.xpath("./td[3]")).getText();

        String emailThucTe =
            dongDauTien.findElement(By.xpath("./td[5]")).getText();

        String ngaySinhThucTe =
            dongDauTien.findElement(By.xpath("./td[6]")).getText();

        String diaChiThucTe =
            dongDauTien.findElement(By.xpath("./td[8]")).getText();

        System.out.println("===== KẾT QUẢ SO SÁNH SAU UPDATE =====");

        compare("Tên", tenThucTe, tenMongDoi);
        compare("Email", emailThucTe, emailMongDoi);
        compare("Ngày sinh", ngaySinhThucTe, ngaySinhMongDoi);
        compare("Địa chỉ", diaChiThucTe, diaChiMoi);

        System.out.println("=====================================");
    }

    void compare(String field, String actual, String expected) {

        if (actual.trim().equalsIgnoreCase(expected.trim())) {
            System.out.println(
                field + " : PASS | Actual = " + actual + " | Expected = " + expected
            );
        } else {
            System.out.println(
                field + " : FAIL | Actual = " + actual + " | Expected = " + expected
            );
        }
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
