package Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

public class delete_stu {

    WebDriver driver;
    WebDriverWait wait;

    String baseUrl = "https://elearning.plt.pro.vn/dang-nhap?redirect=%2Ftrang-chu";
    String driverPath = "C:\\chromedriver.exe";

    // ===== DỮ LIỆU TEST =====
    String emailCanXoa = "nguyenvanchi@gmail.com";

    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, 10);

        driver.manage().window().maximize();
        driver.get(baseUrl);
        Thread.sleep(3000);

        // LOGIN
        driver.findElement(By.id("input-10"))
                .sendKeys("test.pltsolutions@gmail.com");
        driver.findElement(By.id("input-13"))
                .sendKeys("plt@intern_051224");

        driver.findElement(By.xpath(
                "//*[@id='app']/div/main/div/div[1]/div/div[3]/form/div[2]/button/span"
        )).click();

        Thread.sleep(4000);

        // MENU QUẢN LÝ HỌC VIÊN
        driver.findElement(By.xpath(
                "//*[@id='app']/div/nav/div[1]/div[2]/a[2]/div[2]"
        )).click();

        Thread.sleep(3000);
    }

    @Test
    public void XoaHocVien() throws InterruptedException {

        // ===== SEARCH HỌC VIÊN TRƯỚC =====
        WebElement searchInput = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//label[normalize-space()='Search']/following::input[1]")
            )
        );

        searchInput.clear();
        searchInput.sendKeys(emailCanXoa); // email hoặc tên
        Thread.sleep(3000);

        // ===== CLICK ICON ❌ XÓA (ROW ĐẦU TIÊN) =====
        WebElement btnXoa = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//button[.//i[contains(@class,'mdi-close')]]")
            )
        );
        btnXoa.click();

        // ===== CHỜ POPUP XÁC NHẬN =====
        WebElement btnConfirmXoa = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//div[contains(@class,'v-dialog--active')]//button[.//span[normalize-space()='Xóa']]")
            )
        );
        btnConfirmXoa.click();

        Thread.sleep(3000);

        System.out.println("✅ Đã xóa học viên thành công");
    }

    @AfterTest
    public void tearDown() {
        try {
            driver.close();   // ❗ KHÔNG dùng quit()
        } catch (Exception e) {
            System.out.println("⚠️ Browser already closed");
        }
    }
}