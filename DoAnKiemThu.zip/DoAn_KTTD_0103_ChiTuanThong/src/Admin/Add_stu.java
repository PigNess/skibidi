package Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class Add_stu {

    WebDriver driver;
    WebDriverWait wait;

    String baseUrl = "https://elearning.plt.pro.vn/dang-nhap?redirect=%2Ftrang-chu";
    String driverPath = "C:\\chromedriver.exe";

    // ===== DỮ LIỆU MONG ĐỢI (QUY ĐỊNH TRƯỚC) =====
    String tenHocVien = "Nguyen Van Chi";
    String maSoHV = "SV27364";
    String soDienThoai = "0973527452";
    String email = "nguyenvanchi@gmail.com";
    String ngaySinh = "01-01-2000";
    String diaChi = "65/12 An Phu, Thu Duc, TP HCM";
    String gioiTinh = "Nam"; // Nam | Nữ | Khác

    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, 10);

        driver.manage().window().maximize();

        // ===== LOGIN =====
        driver.get(baseUrl);
        Thread.sleep(3000);

        driver.findElement(By.id("input-10"))
                .sendKeys("test.pltsolutions@gmail.com");

        driver.findElement(By.id("input-13"))
                .sendKeys("plt@intern_051224");

        driver.findElement(By.xpath(
                "//*[@id='app']/div/main/div/div[1]/div/div[3]/form/div[2]/button/span"
        )).click();

        Thread.sleep(4000);

        // ===== MENU QUẢN LÝ HỌC VIÊN =====
        driver.findElement(By.xpath(
                "//*[@id='app']/div/nav/div[1]/div[2]/a[2]/div[2]"
        )).click();

        Thread.sleep(3000);
    }

    @Test
    public void ThemHocVien_Va_SoSanhThongTin() throws InterruptedException {

        // ===== LẦN 1: THÊM → HỦY =====
        moFormThemHocVien();
        nhapThongTinHocVien();
        chonGioiTinhTheoData();
        clickHuy();

        // ===== LẦN 2: THÊM → LƯU =====
        moFormThemHocVien();
        nhapThongTinHocVien();
        chonGioiTinhTheoData();
        clickLuu();

        // ===== CHỜ LOAD DANH SÁCH =====
        Thread.sleep(3000);

        // ===== SO SÁNH THÔNG TIN HỌC VIÊN =====
        soSanhThongTinHocVien();
    }

    // ================== HÀM DÙNG CHUNG ==================

    void moFormThemHocVien() throws InterruptedException {
        driver.findElement(By.xpath(
                "//*[@id='v-main-app']/div/div/div/div[1]/header/div/button[1]"
        )).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form")));
        Thread.sleep(2000);
    }

    void nhapThongTinHocVien() {

        driver.findElement(By.xpath(
                "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[1]//input"
        )).sendKeys(tenHocVien);

        driver.findElement(By.xpath(
                "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[2]//input"
        )).sendKeys(maSoHV);

        driver.findElement(By.xpath(
                "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[4]//input"
        )).sendKeys(soDienThoai);

        driver.findElement(By.xpath(
                "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[3]//input"
        )).sendKeys(email);

        driver.findElement(By.xpath(
                "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[5]//input"
        )).sendKeys(ngaySinh);

        driver.findElement(By.xpath(
                "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[7]//input"
        )).sendKeys(diaChi);
    }

    void chonGioiTinhTheoData() {

        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@role='radiogroup']")
        ));

        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//label[normalize-space(text())='" + gioiTinh + "']")
        )).click();
    }

    void clickHuy() throws InterruptedException {

        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//form//div[contains(@class,'v-card__actions')]//button[1]")
        )).click();

        Thread.sleep(3000);
    }

    void clickLuu() throws InterruptedException {

        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//form//div[contains(@class,'v-card__actions')]//button[2]")
        )).click();

        Thread.sleep(4000);
    }

    // ================== PHẦN SO SÁNH (TRỌNG TÂM BÀI) ==================

    void soSanhThongTinHocVien() {

        // ===== LẤY GIÁ TRỊ THỰC TẾ TRÊN BẢNG =====
        String tenThucTe = driver.findElement(By.xpath(
                "//*[@id=\"v-main-app\"]/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[2]"   // TODO: CỘT TÊN
        )).getText();

        String emailThucTe = driver.findElement(By.xpath(
                "//*[@id=\"v-main-app\"]/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[5]"   // TODO: CỘT EMAIL
        )).getText();

        String ngaySinhThucTe = driver.findElement(By.xpath(
                "//*[@id=\"v-main-app\"]/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[6]"   // TODO: CỘT NGÀY SINH
        )).getText();

        String diaChiThucTe = driver.findElement(By.xpath(
                "//*[@id=\"v-main-app\"]/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[8]"   // TODO: CỘT ĐỊA CHỈ
        )).getText();

        System.out.println("===== SO SÁNH THÔNG TIN HỌC VIÊN =====");

        compare("Tên", tenThucTe, tenHocVien);
        compare("Email", emailThucTe, email);
        compare("Ngày sinh", ngaySinhThucTe, ngaySinh);
        compare("Địa chỉ", diaChiThucTe, diaChi);
    }

    void compare(String field, String actual, String expected) {
        if (actual.trim().equalsIgnoreCase(expected.trim())) {
            System.out.println(" PASS: "+ field + actual);
        } else {
            System.out.println(" FAIL " + field);
            System.out.println("Mong Đợi : " + expected + "  Thực Tế  : " + actual);
        }
    }

    @AfterTest
    public void tearDown() {
        driver.close();
    }
}
