package User;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.*;

import java.util.List;

public class kiemtra {

    WebDriver driver;
    WebDriverWait wait;

    String baseUrl = "https://elearning.plt.pro.vn/trang-chu"; // TODO

    // ===== DỮ LIỆU MONG ĐỢI =====
    String tenMonHoc = "Lập trình Java cơ bản"; // TODO: tên môn học mong đợi

    String[] chuongMongDoi = {
        "Giới thiệu Java",
        "Cấu trúc điều khiển",
        "OOP trong Java"
    };

    String[][] baiMongDoi = {
        {"Java là gì?", "Cài đặt môi trường"},
        {"If Else", "Switch Case", "Vòng lặp"},
        {"Class & Object", "Kế thừa", "Đa hình"}
    };

    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe"); // TODO
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, 10);

        driver.manage().window().maximize();

        // ===== LOGIN USER =====
        driver.get(baseUrl);
        Thread.sleep(3000);

        driver.findElement(By.id("input-10")) // TODO
              .sendKeys("test1.pltsolutions@gmail.com");       // TODO

        driver.findElement(By.id("input-13")) // TODO
              .sendKeys("plt@intern_051224");                  // TODO

        driver.findElement(By.xpath("//*[@id=\"app\"]/div/main/div/div[1]/div/div[3]/form/div[2]/button/span")) // TODO
              .click();

        Thread.sleep(4000);
    }

    @Test
    public void XemMonHoc_MoChuong_MoBai_SoSanhTen() throws InterruptedException {

        // ===== VÀO TRANG KHÓA HỌC =====
        driver.findElement(By.xpath(
            "//a[contains(text(),'Khóa học')]"
        )).click(); // TODO

        Thread.sleep(3000);

        // ===== CHỌN MÔN HỌC =====
        driver.findElement(By.xpath(
            "//div[contains(text(),'" + tenMonHoc + "')]"
        )).click(); // TODO

        Thread.sleep(3000);

        // ===== LẤY DANH SÁCH CHƯƠNG =====
        List<WebElement> dsChuong = wait.until(
            ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath("//div[@class='chuong-item']") // TODO
            )
        );

        System.out.println("🔎 SỐ CHƯƠNG TÌM ĐƯỢC: " + dsChuong.size());

        for (int i = 0; i < chuongMongDoi.length; i++) {

            WebElement chuong = dsChuong.get(i);

            String tenChuongThucTe = chuong.getText();
            String tenChuongMongDoi = chuongMongDoi[i];

            // ===== SO SÁNH CHƯƠNG =====
            if (tenChuongThucTe.equalsIgnoreCase(tenChuongMongDoi)) {
                System.out.println("✅ CHƯƠNG PASS: " + tenChuongThucTe);
            } else {
                System.out.println("❌ CHƯƠNG FAIL: " + tenChuongThucTe);
            }

            // ===== MỞ RỘNG CHƯƠNG =====
            chuong.click();
            Thread.sleep(2000);

            // ===== LẤY DANH SÁCH BÀI =====
            List<WebElement> dsBai = chuong.findElements(
                By.xpath(".//div[@class='bai-item']") // TODO
            );

            for (int j = 0; j < baiMongDoi[i].length; j++) {

                String baiThucTe = dsBai.get(j).getText();
                String baiExpect = baiMongDoi[i][j];

                // ===== SO SÁNH BÀI =====
                if (baiThucTe.equalsIgnoreCase(baiExpect)) {
                    System.out.println("   ✔ BÀI PASS: " + baiThucTe);
                } else {
                    System.out.println("   ✘ BÀI FAIL: " + baiThucTe);
                }
            }
        }

        System.out.println("🎉 HOÀN TẤT KIỂM THỬ MÔN HỌC");
    }

    @AfterTest
    public void tearDown() {
        try {
            driver.close();
        } catch (Exception e) {
            System.out.println("⚠️ Trình duyệt đã đóng");
        }
    }
}
