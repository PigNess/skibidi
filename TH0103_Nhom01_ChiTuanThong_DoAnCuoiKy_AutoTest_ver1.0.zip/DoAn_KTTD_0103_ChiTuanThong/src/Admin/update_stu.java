package Admin;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.*;

/**
 * ========================================================= 
 * TEST CASE: UPDATE STUDENT & VERIFY INFORMATION
 *
 * MÔ TẢ: 
 * 1. Đăng nhập hệ thống với quyền Admin 
 * 2. Vào màn hình Quản lý học viên 
 * 3. Tìm kiếm học viên theo từ khóa 
 * 4. Chỉnh sửa thông tin (Địa chỉ) 
 * 5. Lưu thay đổi và xác nhận popup 
 * 6. Tìm kiếm lại học viên 
 * 7. So sánh thông tin hiển thị với dữ liệu mong đợi: 
 * - Tên 
 * - Email 
 * - Ngày sinh 
 * - Địa chỉ (đã update)
 * =========================================================
 */
public class update_stu {

    // ================== DRIVER ==================
    WebDriver driver;
    WebDriverWait wait;

    // ================== CONFIG ==================
    String baseUrl = "https://elearning.plt.pro.vn/dang-nhap?redirect=%2Ftrang-chu";
    String driverPath = "C:\\chromedriver.exe";

    // ================== TEST DATA ==================
    String keywordSearch = "sv12005";

    // ================== EXPECTED DATA ==================
    String tenMongDoi = "Nguyen Van Chi";
    String emailMongDoi = "nguyenvanchi@gmail.com";
    String ngaySinhMongDoi = "01-01-2000";
    String diaChiMoi = "Ha Giáp, Quan 10, TP HCM";

    // =====================================================
    // SETUP – KHỞI TẠO DRIVER & LOGIN
    // =====================================================
    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, 10);

        driver.manage().window().maximize();
        driver.get(baseUrl);
        Thread.sleep(3000);

        // ===== LOGIN =====
        driver.findElement(By.id("input-10")).sendKeys("test.pltsolutions@gmail.com");

        driver.findElement(By.id("input-13")).sendKeys("plt@intern_051224");

        driver.findElement(By.xpath("//*[@id='app']/div/main/div/div[1]/div/div[3]/form/div[2]/button/span")).click();

        Thread.sleep(4000);

        // ===== VÀO QUẢN LÝ HỌC VIÊN =====
        driver.findElement(By.xpath("//*[@id='app']/div[1]/nav/div[1]/div[2]/a[2]/div[2]")).click();

        Thread.sleep(3000);
    }

    // =====================================================
    // TEST CASE CHÍNH
    // =====================================================
    @Test
    public void UpdateHocVien_Va_SoSanhThongTin() throws InterruptedException {

        // ===== SEARCH HỌC VIÊN =====
        WebElement searchBox = wait.until(
                ExpectedConditions.elementToBeClickable(By.xpath("//label[normalize-space()='Search']/following::input[1]")));
        searchBox.clear();
        searchBox.sendKeys(keywordSearch);
        Thread.sleep(2000);

        // ===== CLICK ICON SỬA =====
        driver.findElement(By.xpath("//table/tbody/tr[1]//i[contains(@class,'mdi-pencil')]")).click();

        Thread.sleep(2000);

        // ===== SỬA ĐỊA CHỈ =====
        WebElement diaChiInput = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[normalize-space()='Địa chỉ']/following::input[1]")));

        diaChiInput.click();
        diaChiInput.sendKeys(Keys.CONTROL + "a");
        diaChiInput.sendKeys(Keys.DELETE);
        Thread.sleep(500);
        diaChiInput.sendKeys(diaChiMoi);

        // ===== LƯU =====
        driver.findElement(By.xpath("//form//button[@type='submit']")).click();

        // ===== XÁC NHẬN POPUP =====
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'swal2-confirm')]"))).click();

        System.out.println("✅ UPDATE THÀNH CÔNG");
        Thread.sleep(3000);

        // ===== SEARCH LẠI SAU UPDATE =====
        searchBox.sendKeys(Keys.CONTROL + "a");
        searchBox.sendKeys(Keys.DELETE);
        searchBox.sendKeys(keywordSearch);
        Thread.sleep(2000);

        WebElement dongDauTien = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table/tbody/tr[1]")));

        System.out.println("✅ Tìm thấy dòng kết quả sau UPDATE");

        // ===== SO SÁNH THÔNG TIN =====
        soSanhThongTinHocVien(dongDauTien);
    }

    // =====================================================
    // SO SÁNH THÔNG TIN HỌC VIÊN
    // =====================================================
    void soSanhThongTinHocVien(WebElement row) {

        // ===== LẤY GIÁ TRỊ THỰC TẾ TỪ BẢNG =====
        String tenThucTe = row.findElement(By.xpath("./td[2]")).getText() + " " + row.findElement(By.xpath("./td[3]")).getText();

        String emailThucTe = row.findElement(By.xpath("./td[5]")).getText();

        String ngaySinhThucTe = row.findElement(By.xpath("./td[6]")).getText();

        String diaChiThucTe = row.findElement(By.xpath("./td[8]")).getText();

        System.out.println("===== KẾT QUẢ SO SÁNH SAU UPDATE =====");

        compare("Tên", tenThucTe, tenMongDoi);
        compare("Email", emailThucTe, emailMongDoi);
        compare("Ngày sinh", ngaySinhThucTe, ngaySinhMongDoi);
        compare("Địa chỉ", diaChiThucTe, diaChiMoi);

        System.out.println("=====================================");
    }

    /**
     * Hàm so sánh Actual vs Expected và in kết quả
     */
    void compare(String field, String actual, String expected) {

        if (actual.trim().equalsIgnoreCase(expected.trim())) {
            System.out.println(" PASS | " + field + " Thực tế " + actual);
        } else {
            System.out.println(" FAIL | " + field + " Thực tế " + actual + " Mong đợi " + expected);
            System.out.println();
        }
    }

    // =====================================================
 // TEARDOWN
    // =====================================================
    @AfterTest
    public void tearDown() {
        if (driver != null) {
            driver.close(); 
        }
    }
}