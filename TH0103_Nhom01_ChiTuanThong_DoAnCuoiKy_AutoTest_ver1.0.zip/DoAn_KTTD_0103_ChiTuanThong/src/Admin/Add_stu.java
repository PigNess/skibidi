package Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.*;

/**
 * =========================================================
 * TEST CASE: ADD STUDENT + VERIFY INFORMATION
 * MÔ TẢ:
 *  - Thêm học viên (Hủy lần 1, Lưu lần 2)
 *  - Sau khi thêm thành công, so sánh thông tin hiển thị
 *    với dữ liệu mong đợi đã quy định trước
 * =========================================================
 */
public class Add_stu {

    // ================== KHAI BÁO DRIVER ==================
    WebDriver driver;
    WebDriverWait wait;

    // ================== CẤU HÌNH ==================
    String baseUrl   = "https://elearning.plt.pro.vn/dang-nhap?redirect=%2Ftrang-chu";
    String driverPath = "C:\\chromedriver.exe";

    // ================== DỮ LIỆU TEST (EXPECTED DATA) ==================
    String tenHocVien  = "Nguyen Van Chi";
    String maSoHV      = "SV27364";
    String soDienThoai = "0973527452";
    String email       = "nguyenvanchi@gmail.com";
    String ngaySinh    = "01-01-2000";
    String diaChi      = "65/12 An Phu, Thu Duc, TP HCM";
    String gioiTinh    = "Nam"; // Nam | Nữ | Khác

    // =====================================================
    // SETUP – KHỞI TẠO DRIVER & LOGIN
    // =====================================================
    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        wait   = new WebDriverWait(driver, 10);

        driver.manage().window().maximize();
        driver.get(baseUrl);
        Thread.sleep(3000);

        // ===== LOGIN ADMIN =====
        driver.findElement(By.id("input-10"))
              .sendKeys("test.pltsolutions@gmail.com");

        driver.findElement(By.id("input-13"))
              .sendKeys("plt@intern_051224");

        driver.findElement(By.xpath(
            "//*[@id='app']/div/main/div/div[1]/div/div[3]/form/div[2]/button/span"
        )).click();

        Thread.sleep(4000);

        // ===== VÀO MENU QUẢN LÝ HỌC VIÊN =====
        driver.findElement(By.xpath(
            "//*[@id='app']/div/nav/div[1]/div[2]/a[2]/div[2]"
        )).click();

        Thread.sleep(3000);
    }

    // =====================================================
    // TEST CASE CHÍNH
    // =====================================================
    @Test
    public void ThemHocVien_Va_SoSanhThongTin() throws InterruptedException {

        // ===== LẦN 1: THÊM → HỦY =====
        moFormThemHocVien();
        nhapThongTinHocVien();
        chonGioiTinhTheoData();
        clickHuy();

        // ===== LẦN 2: THÊM → LƯU =====
        moFormThemHocVien();
        nhapThongTinHocVien();
        chonGioiTinhTheoData();
        clickLuu();

        // ===== CHỜ LOAD DANH SÁCH =====
        Thread.sleep(3000);

        // ===== SO SÁNH THÔNG TIN HỌC VIÊN =====
        soSanhThongTinHocVien();
    }

    // =====================================================
    // HÀM DÙNG CHUNG – THAO TÁC FORM
    // =====================================================

    /**
     * Mở popup thêm học viên
     */
    void moFormThemHocVien() throws InterruptedException {
        driver.findElement(By.xpath(
            "//*[@id='v-main-app']/div/div/div/div[1]/header/div/button[1]"
        )).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form")));
        Thread.sleep(2000);
    }

    /**
     * Nhập thông tin học viên theo dữ liệu test
     */
    void nhapThongTinHocVien() {

        driver.findElement(By.xpath(
            "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[1]//input"
        )).sendKeys(tenHocVien);

        driver.findElement(By.xpath(
            "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[2]//input"
        )).sendKeys(maSoHV);

        driver.findElement(By.xpath(
            "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[4]//input"
        )).sendKeys(soDienThoai);

        driver.findElement(By.xpath(
            "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[3]//input"
        )).sendKeys(email);

        driver.findElement(By.xpath(
            "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[5]//input"
        )).sendKeys(ngaySinh);

        driver.findElement(By.xpath(
            "//*[@id='app']/div[3]/div/div/form/div[1]/div/div[7]//input"
        )).sendKeys(diaChi);
    }

    /**
     * Chọn giới tính dựa trên dữ liệu test
     */
    void chonGioiTinhTheoData() {

        wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//div[@role='radiogroup']")
        ));

        wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//label[normalize-space(text())='" + gioiTinh + "']")
        )).click();
    }

    /**
     * Click nút HỦY
     */
    void clickHuy() throws InterruptedException {

        wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//form//div[contains(@class,'v-card__actions')]//button[1]")
        )).click();

        Thread.sleep(3000);
    }

    /**
     * Click nút LƯU
     */
    void clickLuu() throws InterruptedException {

        wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//form//div[contains(@class,'v-card__actions')]//button[2]")
        )).click();

        Thread.sleep(4000);
    }

    // =====================================================
    // SO SÁNH THÔNG TIN – TRỌNG TÂM BÀI
    // =====================================================
    void soSanhThongTinHocVien() {

        // ===== LẤY GIÁ TRỊ THỰC TẾ TRÊN DÒNG ĐẦU TIÊN =====
        String tenThucTe = driver.findElement(By.xpath(
            "//*[@id='v-main-app']/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[2]"
        )).getText();

        String emailThucTe = driver.findElement(By.xpath(
            "//*[@id='v-main-app']/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[5]"
        )).getText();

        String ngaySinhThucTe = driver.findElement(By.xpath(
            "//*[@id='v-main-app']/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[6]"
        )).getText();

        String diaChiThucTe = driver.findElement(By.xpath(
            "//*[@id='v-main-app']/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[8]"
        )).getText();

        System.out.println("===== SO SÁNH THÔNG TIN HỌC VIÊN =====");

        compare("Tên", tenThucTe, tenHocVien);
        compare("Email", emailThucTe, email);
        compare("Ngày sinh", ngaySinhThucTe, ngaySinh);
        compare("Địa chỉ", diaChiThucTe, diaChi);
    }

    /**
     * Hàm so sánh Thực tế vs Mong đợi
     */
    void compare(String field, String actual, String expected) {

        if (actual.trim().equalsIgnoreCase(expected.trim())) {
            System.out.println(field + " : " + actual + "  PASS");
        } else {
            System.out.println(field +" Mong đợi: " + expected + "  Thực tế  : " + actual + "  FAIL" );
            System.out.println();
        }
    }
}
    // =============================
