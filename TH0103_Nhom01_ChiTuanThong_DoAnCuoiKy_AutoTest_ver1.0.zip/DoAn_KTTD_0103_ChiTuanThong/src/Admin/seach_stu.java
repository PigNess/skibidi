package Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.*;

/**
 * =========================================================
 * TEST CASE: SEARCH STUDENT + VERIFY INFORMATION
 * MÔ TẢ:
 *  - Tìm kiếm học viên theo từ khóa (Mã/Tên)
 *  - Lấy dòng kết quả đầu tiên
 *  - So sánh các thông tin hiển thị:
 *      + Tên
 *      + Email
 *      + Ngày sinh
 *      + Địa chỉ
 *  - So sánh với dữ liệu mong đợi đã quy định trước
 * =========================================================
 */
public class seach_stu {

    // ================== KHAI BÁO DRIVER ==================
    WebDriver driver;
    WebDriverWait wait;

    // ================== CẤU HÌNH ==================
    String baseUrl   = "https://elearning.plt.pro.vn/dang-nhap?redirect=%2Ftrang-chu";
    String driverPath = "C:\\chromedriver.exe";

    // ================== DỮ LIỆU SEARCH ==================
    String keywordSearch = "SV27364";

    // ================== DỮ LIỆU MONG ĐỢI (EXPECTED DATA) ==================
    String tenMongDoi      = "Nguyen Van";
    String emailMongDoi    = "nguyenvanchi@gmail.com";
    String ngaySinhMongDoi = "01-02-2000";
    String diaChiMongDoi   = "64/12 An Phu, Thu Duc, TP HCM";

    // =====================================================
    // SETUP – KHỞI TẠO DRIVER & LOGIN
    // =====================================================
    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        wait   = new WebDriverWait(driver, 10);

        driver.manage().window().maximize();

        // ===== LOGIN ADMIN =====
        driver.get(baseUrl);
        Thread.sleep(3000);

        driver.findElement(By.id("input-10"))
              .sendKeys("test.pltsolutions@gmail.com");

        driver.findElement(By.id("input-13"))
              .sendKeys("plt@intern_051224");

        driver.findElement(By.xpath(
            "//*[@id='app']/div/main/div/div[1]/div/div[3]/form/div[2]/button/span"
        )).click();

        Thread.sleep(4000);

        // ===== VÀO MENU QUẢN LÝ HỌC VIÊN =====
        driver.findElement(By.xpath(
            "//*[@id='app']/div[1]/nav/div[1]/div[2]/a[2]/div[2]"
        )).click();

        Thread.sleep(3000);
    }

    // =====================================================
    // TEST CASE CHÍNH
    // =====================================================
    @Test
    public void TimKiemHocVien_TheoTen() throws InterruptedException {

        // ===== NHẬP TỪ KHÓA SEARCH =====
        WebElement searchBox = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//*[@id='input-41']")
                // TODO: Nếu ID thay đổi → chỉnh XPath cho đúng ô Search
            )
        );

        searchBox.clear();
        searchBox.sendKeys(keywordSearch);

        Thread.sleep(2000);

        // ===== LẤY DÒNG KẾT QUẢ ĐẦU TIÊN =====
        WebElement dongDauTien = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[@id='v-main-app']/div/div/div/div[1]/div[1]/table/tbody/tr[1]")
            )
        );

        System.out.println("Tìm thấy dòng kết quả");

        // ===== SO SÁNH THÔNG TIN HỌC VIÊN =====
        soSanhThongTinHocVien(dongDauTien);
    }

    // =====================================================
    // SO SÁNH THÔNG TIN HỌC VIÊN
    // =====================================================
    void soSanhThongTinHocVien(WebElement dongDauTien) {

        // ===== LẤY GIÁ TRỊ THỰC TẾ TỪ BẢNG =====
        String tenThucTe =
            dongDauTien.findElement(By.xpath(
                "//*[@id='v-main-app']/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[2]"
            )).getText()
            + " " +
            dongDauTien.findElement(By.xpath(
                "//*[@id='v-main-app']/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[3]"
            )).getText();

        String emailThucTe =
            dongDauTien.findElement(By.xpath(
                "//*[@id='v-main-app']/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[5]"
            )).getText();

        String ngaySinhThucTe =
            dongDauTien.findElement(By.xpath(
                "//*[@id='v-main-app']/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[6]"
            )).getText();

        String diaChiThucTe =
            dongDauTien.findElement(By.xpath(
                "//*[@id='v-main-app']/div/div/div/div[1]/div[1]/table/tbody/tr[1]/td[8]"
            )).getText();

        System.out.println("===== KẾT QUẢ SO SÁNH HỌC VIÊN =====");

        soSanhVaInKetQua("Tên", tenThucTe, tenMongDoi);
        soSanhVaInKetQua("Email", emailThucTe, emailMongDoi);
        soSanhVaInKetQua("Ngày sinh", ngaySinhThucTe, ngaySinhMongDoi);
        soSanhVaInKetQua("Địa chỉ", diaChiThucTe, diaChiMongDoi);

        System.out.println("===================================");
    }

    /**
     * Hàm so sánh Actual vs Expected và in kết quả
     */
    void soSanhVaInKetQua(String field, String actual, String expected) {

        actual   = actual.trim();
        expected = expected.trim();

        if (actual.equalsIgnoreCase(expected)) {
            System.out.println(
                "PASS | " + field +
                " | Thực tế  " + actual +
                " | Mong đợi  " + expected
            );
        } else {
            System.out.println(
                "FAIL | " + field +
                " | Thực tế  " + actual +
                " | Mong đợi  " + expected
            );
        }
    }

    // =====================================================
    // TEARDOWN
    // =====================================================
    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
