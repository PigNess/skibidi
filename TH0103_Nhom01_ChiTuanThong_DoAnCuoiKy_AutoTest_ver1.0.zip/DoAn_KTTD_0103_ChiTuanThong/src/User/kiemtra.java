package User;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.*;

public class kiemtra {

    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;

    String baseUrl   = "https://elearning.plt.pro.vn/dang-nhap";
    String driverPath = "C:\\chromedriver.exe";

    // ===== DỮ LIỆU MONG ĐỢI (EXPECTED DATA) =====
    String tenChuongMongDoi = "CHƯƠNG 1: TỔNG QUAN VỀ TIN HỌC";
    String tenBaiMongDoi    = "Bài số 1: Khái niệm Tin học";

    @BeforeTest
    public void setup() throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        wait   = new WebDriverWait(driver, 15);
        js     = (JavascriptExecutor) driver;

        driver.manage().window().maximize();
        driver.get(baseUrl);
        Thread.sleep(3000);

        // ===== LOGIN HỌC VIÊN =====
        driver.findElement(By.id("input-10"))
              .sendKeys("test1.pltsolutions@gmail.com");

        driver.findElement(By.id("input-13"))
              .sendKeys("plt@intern_051224");

        driver.findElement(By.xpath(
            "//*[@id='app']/div/main/div/div[1]/div/div[3]/form/div[2]/button/span"
        )).click();

        Thread.sleep(4000);
    }

    @Test
    public void KiemTra_Chuong_Bai_Va_DieuHuong() throws InterruptedException {

        // ===== 1. VÀO KHÓA HỌC: TIN HỌC ĐẠI CƯƠNG =====
        WebElement monHoc = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//*[@id='app']/div/nav/div[1]/div[2]/div[1]/div[2]/a[2]")
        ));
        js.executeScript("arguments[0].scrollIntoView(true);", monHoc);
        monHoc.click();
        Thread.sleep(3000);

        // ===== 2. TAB "NỘI DUNG MÔN HỌC" =====
        WebElement tabNoiDung = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//*[@id='v-main-app']//div[contains(@class,'v-tab')][2]")
        ));
        js.executeScript("arguments[0].click();", tabNoiDung);
        Thread.sleep(2000);

        // ===== 3. MỞ CHƯƠNG 1 =====
        WebElement chuong1 = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//*[@id='v-main-app']//button[contains(.,'CHƯƠNG 1')]")
        ));

        String tenChuongThucTe = chuong1.getText();
        js.executeScript("arguments[0].click();", chuong1);
        Thread.sleep(2000);

        // ===== 4. MỞ BÀI 1 =====
        WebElement bai1 = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//*[@id='v-main-app']//button[contains(.,'Bài số 1')]")
        ));

        String tenBaiThucTe = bai1.getText();
        js.executeScript("arguments[0].click();", bai1);
        Thread.sleep(2000);

        // ===== 5. CHUYỂN SANG DIỄN ĐÀN THẢO LUẬN =====
        WebElement tabDienDan = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//*[@id='v-main-app']//div[contains(@class,'v-tab')][3]")
        ));
        js.executeScript("arguments[0].click();", tabDienDan);
        Thread.sleep(2000);

        // ===== 6. CHUYỂN SANG VIDEO =====
        WebElement tabVideo = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//*[@id='v-main-app']//div[contains(@class,'v-tab')][4]")
        ));
        js.executeScript("arguments[0].click();", tabVideo);
        Thread.sleep(2000);

        // ===== 7. THAM GIA CUỘC GỌI =====
        WebElement joinBtn = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//a//span[contains(text(),'Tham gia')]")
        ));
        js.executeScript("arguments[0].click();", joinBtn);

        Thread.sleep(5000);

        // ===== 8. QUAY LẠI TRANG TRƯỚC =====
        driver.navigate().back();
        driver.navigate().back();
        Thread.sleep(2000);

        // ===== 9. SO SÁNH KẾT QUẢ =====
        System.out.println("===== KẾT QUẢ SO SÁNH =====");
        soSanh("Chương", tenChuongThucTe, tenChuongMongDoi);
        soSanh("Bài", tenBaiThucTe, tenBaiMongDoi);
        System.out.println("===========================");
    }

    // ===== HÀM SO SÁNH (CHUẨN TEST CASE) =====
    void soSanh(String truong, String thucTe, String mongDoi) {

        if (thucTe.trim().equalsIgnoreCase(mongDoi.trim())) {
            System.out.println( truong + " PASS | Thực tế: " + thucTe);
        } else {
            System.out.println( truong + " FAIL");
            System.out.println("   Thực tế : " + thucTe);
            System.out.println("   Mong đợi: " + mongDoi);
        }
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
